/* =========================================
   УТИЛИТЫ
   ========================================= */
function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

/* =========================================
   СОСТОЯНИЕ
   ========================================= */
const CATEGORIES = ["chronology", "persons", "artifacts", "methodology"];
const ROUND_TIME = 30;

let rounds = [];
let current = 0;
let score = 0;
let locked = false;

let timedMode = false;
let learnMode = false;
let timerId = null;

/* DOM */
const roundLabel = document.getElementById("roundLabel");
const questionText = document.getElementById("questionText");
const optionsBox = document.getElementById("optionsBox");
const explanation = document.getElementById("explanation");
const questBody = document.getElementById("questBody");
const result = document.getElementById("result");
const progressBar = document.getElementById("progressBar");
const progressDots = document.querySelectorAll(".progress-dot");
const restartBtn = document.getElementById("restartBtn");
const liveScore = document.getElementById("liveScore");
const copyResultBtn = document.getElementById("copyResultBtn");
const timerEl = document.getElementById("timer");
const timedModeToggle = document.getElementById("timedModeToggle");
const learnModeToggle = document.getElementById("learnModeToggle");
const startQuestBtn = document.getElementById("startQuestBtn");

/* =========================================
   ФОН ПО РАУНДАМ
   ========================================= */
function setBackground(url) {
  if (!url) return;
  const img = new Image();
  img.onload = () => {
    document.documentElement.style.setProperty("--photo", `url("${url}")`);
    document.body.classList.add("bg-loaded");
  };
  img.onerror = () => {
    document.documentElement.style.setProperty("--photo", "none");
  };
  img.src = url;
}

/* =========================================
   ТАЙМЕР
   ========================================= */
function stopTimer() {
  if (timerId) {
    clearInterval(timerId);
    timerId = null;
  }
  timerEl.textContent = "";
  timerEl.classList.remove("urgent", "visible");
}

function startTimer(seconds, onEnd) {
  stopTimer();
  if (!timedMode) return;

  let left = seconds;
  timerEl.classList.add("visible");
  timerEl.textContent = "⏱ " + left + " с";

  timerId = setInterval(() => {
    left--;
    timerEl.textContent = "⏱ " + left + " с";
    timerEl.classList.toggle("urgent", left <= 10);
    if (left <= 0) {
      stopTimer();
      onEnd();
    }
  }, 1000);
}

/* =========================================
   ОСНОВНОЙ КВЕСТ
   ========================================= */
function buildRounds() {
  return CATEGORIES.map(cat => {
    const item = pickRandom(window.QUESTIONS_BANK[cat]);
    return {
      label: "Раунд — " + item.label,
      bg: item.bg || "",
      question: item.question,
      options: shuffle(item.options),
      explanation: item.explanation
    };
  });
}

function updateLiveScore() {
  if (learnMode) {
    liveScore.textContent = "Режим «Учимся» — без счёта";
    liveScore.classList.add("learn");
  } else {
    liveScore.textContent = "Правильно: " + score + " / " + rounds.length;
    liveScore.classList.remove("learn");
  }
}

function renderRound() {
  locked = false;
  const r = rounds[current];

  setBackground(r.bg);
  roundLabel.textContent = r.label;
  questionText.textContent = r.question;
  explanation.classList.remove("show");
  explanation.innerHTML = "";
  optionsBox.innerHTML = "";

  r.options.forEach(function (opt, i) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "option";

    const letter = String.fromCharCode(65 + i);
    const letterSpan = document.createElement("span");
    letterSpan.className = "letter";
    letterSpan.textContent = letter;

    const textSpan = document.createElement("span");
    textSpan.textContent = opt.text;

    btn.appendChild(letterSpan);
    btn.appendChild(textSpan);
    btn.addEventListener("click", () => selectOption(btn, opt.correct));
    optionsBox.appendChild(btn);
  });

  progressDots.forEach((dot, i) => {
    dot.classList.remove("active", "done");
    if (i < current) dot.classList.add("done");
    if (i === current) dot.classList.add("active");
  });
  progressBar.classList.remove("finished");

  updateLiveScore();

  // Таймер
  stopTimer();
  startTimer(ROUND_TIME, () => {
    if (!locked) {
      selectOption(null, false, true);
    }
  });
}

function selectOption(btn, isCorrect, isTimeout = false) {
  if (locked) return;
  locked = true;
  stopTimer();

  const allOptions = optionsBox.querySelectorAll(".option");
  allOptions.forEach(o => o.classList.add("locked"));

  allOptions.forEach(o => {
    const idx = o.querySelector(".letter").textContent.charCodeAt(0) - 65;
    if (rounds[current].options[idx].correct) {
      o.classList.add("correct");
      o.querySelector(".letter").textContent = "✓";
    }
  });

  if (!isCorrect) {
    if (btn) {
      btn.classList.remove("correct");
      btn.classList.add("wrong");
      btn.querySelector(".letter").textContent = "✕";
    }
  } else if (!learnMode) {
    score++;
  }

  updateLiveScore();

  // Разбор
  explanation.innerHTML = "";
  const title = document.createElement("h4");
  title.textContent = isTimeout ? "Время вышло ⏱" : "Разбор";
  explanation.appendChild(title);

  rounds[current].explanation.forEach(text => {
    const p = document.createElement("p");
    p.textContent = text;
    explanation.appendChild(p);
  });

  const nextBtn = document.createElement("button");
  nextBtn.type = "button";
  nextBtn.className = "next-btn";
  nextBtn.textContent = (current === rounds.length - 1)
    ? "Показать результат →"
    : "Следующий раунд →";
  nextBtn.addEventListener("click", nextRound);
  explanation.appendChild(nextBtn);

  explanation.classList.add("show");
}

function nextRound() {
  current++;
  if (current < rounds.length) {
    renderRound();
    document.querySelector(".quest-section").scrollIntoView({ behavior: "smooth" });
  } else {
    showResult();
  }
}

function showResult() {
  stopTimer();
  questBody.style.display = "none";
  result.classList.add("show");
  result.setAttribute("role", "status");
  result.setAttribute("aria-live", "polite");

  const resultScoreEl = document.getElementById("resultScore");
  const title = document.getElementById("resultTitle");
  const text = document.getElementById("resultText");

  if (learnMode) {
    resultScoreEl.innerHTML = "🎓";
    title.textContent = "Режим обучения завершён";
    text.textContent = "Ты прошёл все раунды в режиме без счёта. Перечитай разборы — и попробуй снова уже с очками.";
  } else {
    resultScoreEl.innerHTML = score + "<small>/" + rounds.length + "</small>";
    if (score === rounds.length) {
      title.textContent = "Идеальный детектив 🏆";
      text.textContent = "Ты безошибочно распознаёшь ИИ-галлюцинации. Теперь твоя задача — нести этот навык в массы.";
    } else if (score === rounds.length - 1) {
      title.textContent = "Опытный аналитик 🥈";
      text.textContent = "Отличный результат. Ещё немного практики — и ты станешь мастером фактчекинга.";
    } else if (score === 2) {
      title.textContent = "Внимательный читатель 🥉";
      text.textContent = "Ты замечаешь подвох, но иногда ведёшься на правдоподобные детали. Вернись к чек-листу методологии.";
    } else {
      title.textContent = "Новичок в фактчекинге";
      text.textContent = "Не беда — галлюцинации ИИ умеют быть убедительными. Перечитай разборы и попробуй снова.";
    }
  }

  progressDots.forEach(d => {
    d.classList.remove("active");
    d.classList.add("done");
  });
  progressBar.classList.add("finished");

  if (copyResultBtn) copyResultBtn.style.display = "inline-block";

  // Локальная аналитика
  try {
    const history = JSON.parse(localStorage.getItem("fakeCaseHistory")) || [];
    history.push({
      date: new Date().toISOString(),
      score: learnMode ? null : score,
      total: rounds.length,
      learnMode
    });
    localStorage.setItem("fakeCaseHistory", JSON.stringify(history.slice(-50)));
  } catch (e) { /* ignore */ }
}

function restartQuest() {
  current = 0;
  score = 0;
  rounds = buildRounds();
  result.classList.remove("show");
  questBody.style.display = "block";
  if (copyResultBtn) copyResultBtn.style.display = "none";
  renderRound();
  document.querySelector(".quest-section").scrollIntoView({ behavior: "smooth" });
}

restartBtn.addEventListener("click", restartQuest);

if (copyResultBtn) {
  copyResultBtn.addEventListener("click", async () => {
    const text = learnMode
      ? "Я прошёл обучающий режим квеста «Разоблачение фейка». Попробуй и ты: " + location.href
      : "Я прошёл квест «Разоблачение фейка» на " + score + "/" + rounds.length +
        ". Попробуй и ты: " + location.href;
    try {
      await navigator.clipboard.writeText(text);
      copyResultBtn.textContent = "Скопировано ✓";
      setTimeout(() => { copyResultBtn.textContent = "Скопировать результат"; }, 1800);
    } catch (e) {
      alert("Не удалось скопировать. Вот текст:\n\n" + text);
    }
  });
}

/* Переключатели режимов */
timedModeToggle.addEventListener("change", () => {
  timedMode = timedModeToggle.checked;
  if (timedMode && !locked && questBody.style.display !== "none" && !result.classList.contains("show")) {
    startTimer(ROUND_TIME, () => {
      if (!locked) selectOption(null, false, true);
    });
  } else if (!timedMode) {
    stopTimer();
  }
});

learnModeToggle.addEventListener("change", () => {
  learnMode = learnModeToggle.checked;
  updateLiveScore();
});

/* Кнопка «Начать квест» на главном экране */
if (startQuestBtn) {
  startQuestBtn.addEventListener("click", (e) => {
    e.preventDefault();
    // Если квест уже пройден или начат, сбрасываем его
    if (current !== 0 || score !== 0 || result.classList.contains("show") || locked) {
      restartQuest();
    } else {
      // Если всё чисто, просто скроллим к секции
      document.getElementById("quest").scrollIntoView({ behavior: "smooth" });
      // Если включен таймер, запускаем его
      if (timedMode && !locked) {
        startTimer(ROUND_TIME, () => {
          if (!locked) selectOption(null, false, true);
        });
      }
    }
  });
}

/* Reveal */
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); });
}, { threshold: 0.15 });
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

/* Старт */
rounds = buildRounds();
renderRound();

/* =========================================
   КОНСТРУКТОР ОПРОСОВ
   ========================================= */
const pollForm = document.getElementById("pollForm");
const pollsList = document.getElementById("pollsList");
const noPollsMsg = document.getElementById("noPollsMsg");
const customPlayArea = document.getElementById("customPlayArea");
const customQuestionText = document.getElementById("customQuestionText");
const customOptionsBox = document.getElementById("customOptionsBox");
const customExplanation = document.getElementById("customExplanation");
const closeCustomPlayBtn = document.getElementById("closeCustomPlayBtn");
const builderContainer = document.querySelector(".builder-container");

let savedPolls = JSON.parse(localStorage.getItem("myCustomPolls")) || [];

function renderSavedPolls() {
  pollsList.innerHTML = "";
  if (savedPolls.length === 0) {
    noPollsMsg.style.display = "block";
    return;
  }
  noPollsMsg.style.display = "none";

  savedPolls.forEach(poll => {
    const item = document.createElement("div");
    item.className = "poll-list-item";

    const title = document.createElement("span");
    title.textContent = poll.question;

    const actions = document.createElement("div");
    actions.className = "poll-actions";

    const playBtn = document.createElement("button");
    playBtn.type = "button";
    playBtn.textContent = "Пройти";
    playBtn.addEventListener("click", () => startCustomPoll(poll));

    const delBtn = document.createElement("button");
    delBtn.type = "button";
    delBtn.className = "delete-btn";
    delBtn.textContent = "Удалить";
    delBtn.addEventListener("click", () => {
      if (!confirm("Удалить опрос «" + poll.question + "»?")) return;
      savedPolls = savedPolls.filter(p => p !== poll);
      localStorage.setItem("myCustomPolls", JSON.stringify(savedPolls));
      renderSavedPolls();
    });

    actions.appendChild(playBtn);
    actions.appendChild(delBtn);
    item.appendChild(title);
    item.appendChild(actions);
    pollsList.appendChild(item);
  });
}

pollForm.addEventListener("submit", e => {
  e.preventDefault();

  const question = document.getElementById("pollQuestion").value.trim();
  const optionInputs = document.querySelectorAll(".poll-option-input");
  const correctRadio = document.querySelector('input[name="correctAnswer"]:checked');

  if (!question) { alert("Введи вопрос."); return; }
  if (!correctRadio) { alert("Отметь правильный вариант галочкой."); return; }

  const options = [];
  let empty = false;
  optionInputs.forEach((input, i) => {
    const val = input.value.trim();
    if (!val) empty = true;
    options.push({ text: val, correct: i === Number(correctRadio.value) });
  });

  if (empty) { alert("Заполни все четыре варианта ответа."); return; }
  if (savedPolls.length >= 20) {
    alert("Достигнут лимит в 20 опросов. Удали что-нибудь ненужное.");
    return;
  }

  savedPolls.push({ question, options });
  localStorage.setItem("myCustomPolls", JSON.stringify(savedPolls));
  pollForm.reset();
  renderSavedPolls();
});

function startCustomPoll(poll) {
  builderContainer.style.display = "none";
  customPlayArea.style.display = "block";
  closeCustomPlayBtn.style.display = "none";

  customQuestionText.textContent = poll.question;
  customOptionsBox.innerHTML = "";
  customExplanation.classList.remove("show");
  customExplanation.innerHTML = "";

  const shuffledOptions = shuffle(poll.options);
  let isLocked = false;

  shuffledOptions.forEach((opt, i) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "option";

    const letterSpan = document.createElement("span");
    letterSpan.className = "letter";
    letterSpan.textContent = String.fromCharCode(65 + i);

    const textSpan = document.createElement("span");
    textSpan.textContent = opt.text;

    btn.appendChild(letterSpan);
    btn.appendChild(textSpan);

    btn.addEventListener("click", () => {
      if (isLocked) return;
      isLocked = true;

      const allBtns = customOptionsBox.querySelectorAll(".option");
      allBtns.forEach(b => b.classList.add("locked"));
      allBtns.forEach(b => {
        const idx = b.querySelector(".letter").textContent.charCodeAt(0) - 65;
        if (shuffledOptions[idx] && shuffledOptions[idx].correct) {
          b.classList.add("correct");
          b.querySelector(".letter").textContent = "✓";
        }
      });

      if (!opt.correct) {
        btn.classList.remove("correct");
        btn.classList.add("wrong");
        btn.querySelector(".letter").textContent = "✕";
      }

      customExplanation.innerHTML = "";
      const h4 = document.createElement("h4");
      h4.textContent = "Результат";
      customExplanation.appendChild(h4);

      const p = document.createElement("p");
      p.textContent = opt.correct
        ? "Верно! Отличная работа."
        : "Увы, это неправильный ответ. Правильный выделен зелёным.";
      customExplanation.appendChild(p);

      customExplanation.classList.add("show");
      closeCustomPlayBtn.style.display = "inline-block";
    });

    customOptionsBox.appendChild(btn);
  });
}

closeCustomPlayBtn.addEventListener("click", () => {
  customPlayArea.style.display = "none";
  builderContainer.style.display = "grid";
  builderContainer.scrollIntoView({ behavior: "smooth" });
});

renderSavedPolls();

/* =========================================
   PWA
   ========================================= */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(err => {
      console.warn("Service Worker не зарегистрирован:", err);
    });
  });
}